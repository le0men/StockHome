# Install OCaml
Follow the instructions to download OCaml from this [installation guide](https://cs3110.github.io/textbook/chapters/preface/install.html).

# Dependencies
Follow instructions to download Python 3 from this [python guide]https://realpython.com/installing-python/
Follow instructions to download pip from this [pip guide]https://pip.pypa.io/en/stable/installation/
For first time installation, run `make dependencies` to download dependencies.

# Running the Code
To run the code, simply run `make gui` in the terminal. 